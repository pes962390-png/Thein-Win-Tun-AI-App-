# Thein Win Tun AI Studio — Secure Backend + APK

## Architecture

`Android APK -> HTTPS backend -> Gemini API`

The Gemini key is **never stored in the APK**. The APK only contains `VITE_API_BASE_URL` pointing to the backend.

## 1. Deploy the backend with Google Cloud Run

Requirements: Google Cloud CLI (`gcloud`) installed and logged in, plus a Google Cloud project with billing/API access configured.

From this `server/` folder:

```bash
export PROJECT_ID="your-google-cloud-project-id"
export GEMINI_API_KEY="your-gemini-api-key"
export REGION="us-central1"
./cloudrun-deploy.sh
```

The script prints the HTTPS Cloud Run URL.

For better security, after the first deployment you should move the secret to Secret Manager rather than keeping it in shell history. Do **not** commit `.env` files or API keys.

## 2. Point the APK at the backend

From the project root:

```bash
./scripts/set-backend-url.sh https://YOUR-CLOUD-RUN-URL
npm install
npm run cap:add
npm run cap:build
```

Then open Android Studio:

```bash
npx cap open android
```

Build the debug APK with **Build > Build APK(s)**.

## 3. Important

- Do not put `GEMINI_API_KEY` in `.env.local` or any Vite `VITE_*` variable.
- `VITE_*` values are compiled into the client and are not secrets.
- The backend allow-lists the two Gemini models currently used by the app.
- The backend has a basic per-IP rate limit. For public distribution, add stronger authentication/quotas before large-scale release.
- Google AI Studio/Gemini API availability is region-dependent. The backend should be hosted in a supported environment/region.
