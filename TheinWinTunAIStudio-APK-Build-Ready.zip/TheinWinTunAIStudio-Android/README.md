# Thein Win Tun AI Studio — Android Project

This project wraps the React/Vite app with Capacitor and uses a small server-side Gemini proxy.

## Security architecture

**The Gemini API key is never bundled into the Android APK.** The app calls your backend at `VITE_API_BASE_URL`; the backend keeps `GEMINI_API_KEY` in its server environment and calls Google Gemini.

### 1. Configure the backend

```bash
cd server
npm install
cp .env.example .env
# Edit .env and set GEMINI_API_KEY
npm start
```

Deploy the `server/` directory to your preferred Node.js hosting provider. Keep `GEMINI_API_KEY` as a platform secret/environment variable, not in source control.

### 2. Configure the Android/web build

At the project root:

```bash
cp .env.example .env
# Set VITE_API_BASE_URL to the HTTPS URL of your deployed backend
npm install
npm run build
npm run cap:add
npm run cap:build
```

`VITE_API_BASE_URL` is intentionally not secret; it only identifies your backend. **Never put the Gemini API key in `VITE_*` variables.**

Then open Android Studio:

```bash
npx cap open android
```

Build a debug APK for testing or a signed release APK for distribution.

## Important production notes

- Use HTTPS for the backend.
- Restrict CORS with `ALLOWED_ORIGIN` where practical.
- Keep rate limiting enabled and tune it for your users.
- Rotate/revoke any Gemini key that was previously exposed in a client app.
- The proxy allow-lists the two Gemini models currently used by the app.

## Secure deployment files

- `server/server.mjs` — Gemini proxy; API key stays server-side.
- `server/Dockerfile` — production container for Cloud Run.
- `server/cloudrun-deploy.sh` — deploy helper.
- `scripts/set-backend-url.sh` — writes the APK's backend URL to `.env.local`.
- `DEPLOYMENT.md` — step-by-step deployment/build guide.
