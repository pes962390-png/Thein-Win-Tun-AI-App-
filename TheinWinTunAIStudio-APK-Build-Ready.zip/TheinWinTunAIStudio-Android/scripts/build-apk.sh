#!/usr/bin/env bash
set -e
npm install
npm run cap:add
npm run cap:build
printf '\nNow open Android Studio and build the APK:\n  npx cap open android\n\nThen: Build > Build APK(s)\n'
