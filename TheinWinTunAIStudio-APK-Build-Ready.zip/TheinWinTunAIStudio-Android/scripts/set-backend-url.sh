#!/usr/bin/env bash
set -euo pipefail
URL="${1:-}"
if [[ -z "$URL" ]]; then
  echo "Usage: ./scripts/set-backend-url.sh https://your-backend-url"
  exit 1
fi
printf 'VITE_API_BASE_URL=%s\n' "${URL%/}" > .env.local
echo "Saved .env.local. Run npm run cap:build next."
