#!/usr/bin/env bash
set -euo pipefail

PROJECT_ID="${PROJECT_ID:?Set PROJECT_ID first}"
REGION="${REGION:-us-central1}"
SERVICE="${SERVICE:-twt-ai-backend}"

if [[ -z "${GEMINI_API_KEY:-}" ]]; then
  echo "Set GEMINI_API_KEY in your shell before deploying."
  exit 1
fi

gcloud config set project "$PROJECT_ID"
gcloud run deploy "$SERVICE" \
  --source . \
  --region "$REGION" \
  --allow-unauthenticated \
  --set-env-vars "GEMINI_API_KEY=$GEMINI_API_KEY,ALLOWED_ORIGIN=https://localhost,RATE_LIMIT_PER_MINUTE=30"

echo
echo "Backend URL:"
gcloud run services describe "$SERVICE" --region "$REGION" --format='value(status.url)'
