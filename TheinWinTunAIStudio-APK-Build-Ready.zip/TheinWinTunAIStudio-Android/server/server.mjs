import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

const app = express();
const port = Number(process.env.PORT || 8787);
const apiKey = process.env.GEMINI_API_KEY;
const allowedOrigin = process.env.ALLOWED_ORIGIN || 'https://localhost';
const allowedOrigins = allowedOrigin.split(',').map(s => s.trim()).filter(Boolean);

if (!apiKey) {
  console.error('Missing GEMINI_API_KEY. Set it in the server environment.');
  process.exit(1);
}

app.disable('x-powered-by');
app.use(cors({ origin: allowedOrigins.length === 1 && allowedOrigins[0] === '*' ? true : allowedOrigins }));
app.use(express.json({ limit: '1mb' }));
app.use(rateLimit({ windowMs: 60_000, max: Number(process.env.RATE_LIMIT_PER_MINUTE || 30), standardHeaders: true, legacyHeaders: false }));

const allowedModels = new Set([
  'gemini-2.5-flash-preview-09-2025',
  'gemini-2.5-flash-preview-tts'
]);

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/api/generate', async (req, res) => {
  try {
    const { model, payload } = req.body || {};
    if (!allowedModels.has(model)) return res.status(400).json({ error: 'Unsupported model.' });
    if (!payload || typeof payload !== 'object') return res.status(400).json({ error: 'Invalid payload.' });

    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: req.signal
      }
    );

    const text = await upstream.text();
    res.status(upstream.status).type('application/json').send(text);
  } catch (error) {
    if (error?.name === 'AbortError') return;
    console.error('Gemini proxy error:', error);
    res.status(502).json({ error: 'AI service unavailable.' });
  }
});

app.listen(port, () => console.log(`AI backend listening on :${port}`));
